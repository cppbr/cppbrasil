<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk_UA">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../aboutDlg.cpp" line="29"/>
        <source>About QtRptDesigner</source>
        <translation>О QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="46"/>
        <source>Version: </source>
        <translation>Версія:</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="47"/>
        <source>Programmer: Aleksey Osipov</source>
        <translation>Программист: Алексей Осипов</translation>
    </message>
    <message>
        <source>2012-2014 years</source>
        <translation type="vanished">2012-2014 роки</translation>
    </message>
    <message>
        <source>Thanks to:</source>
        <translation type="vanished">Дякую:</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="48"/>
        <source>Web Site: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="49"/>
        <source>E-mail: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2012-2016 years</source>
        <translation type="vanished">2012-2016 роки</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="51"/>
        <source>2012-2018 years</source>
        <translation>2012-2018 роки</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="52"/>
        <source>Thanks for donation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="54"/>
        <source>Sailendram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="56"/>
        <source>Thanks for project developing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="58"/>
        <source>Lukas Lalinsky for DBmodel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="59"/>
        <source>Norbert Schlia for help in developing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="60"/>
        <source>Muhamad Bashir Al-Noimi for Arabic translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="61"/>
        <source>Luis Brochado for Portuguese translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="62"/>
        <source>Li Wei for Chinese translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="63"/>
        <source>Laurent Guilbert for French translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="64"/>
        <source>David Heremans for Dutch translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="65"/>
        <source>Mirko Marx for German translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="66"/>
        <source>Manuel Soriano for Spanish translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="67"/>
        <source>Bagavathikumar for Tamil translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="68"/>
        <source>Giulio Macchieraldo for Italian translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditFldDlg</name>
    <message>
        <location filename="../EditFldDlg.ui" line="14"/>
        <source>Field editor</source>
        <translation>Редактор поля</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="61"/>
        <location filename="../EditFldDlg.ui" line="176"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="100"/>
        <source>Add variable</source>
        <translation>Додати змінну</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="103"/>
        <location filename="../EditFldDlg.ui" line="123"/>
        <location filename="../EditFldDlg.ui" line="143"/>
        <location filename="../EditFldDlg.ui" line="466"/>
        <location filename="../EditFldDlg.ui" line="483"/>
        <location filename="../EditFldDlg.ui" line="714"/>
        <location filename="../EditFldDlg.ui" line="728"/>
        <location filename="../EditFldDlg.ui" line="742"/>
        <location filename="../EditFldDlg.ui" line="756"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="120"/>
        <source>Add function</source>
        <translation>Додати функцію</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="140"/>
        <source>Add formatting</source>
        <translation>Додати фрматірованіє</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="160"/>
        <source>Text direction</source>
        <translation>Напрямок тексту</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="163"/>
        <source>&lt;-</source>
        <translation></translation>
    </message>
    <message>
        <source>Proccess as Image</source>
        <translation type="vanished">Обробляти як картинку</translation>
    </message>
    <message>
        <source>Attention! You may enter just ONE varibale and not any text.</source>
        <translation type="vanished">Увага! Ви можете внести лише одну змінну і більше жодного тексту.</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="227"/>
        <source>Condtion</source>
        <translation>Умова</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="235"/>
        <source>Printing</source>
        <translation>Друк</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="248"/>
        <source>Hightlighting</source>
        <translation>Подстветка</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="260"/>
        <source>Condition</source>
        <translation>Умова</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="277"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="283"/>
        <source>Bold</source>
        <translation>Жирний</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="290"/>
        <source>Italic</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="297"/>
        <source>Underline</source>
        <translation>Підкреслений</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="304"/>
        <source>Strikeout</source>
        <translation>Перекреслений</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="339"/>
        <location filename="../EditFldDlg.ui" line="405"/>
        <location filename="../EditFldDlg.ui" line="1020"/>
        <location filename="../EditFldDlg.ui" line="1051"/>
        <source>Color...</source>
        <translation>Колір...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="354"/>
        <source>Background</source>
        <translation>Фон</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="360"/>
        <source>Transparent</source>
        <translation>Прозорий</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="370"/>
        <source>Other</source>
        <translation>Інший</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="480"/>
        <source>Save As</source>
        <translation>Зберегти як</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="497"/>
        <source>Ignore aspect ratio</source>
        <translation>Ігнорувати співвідношення сторін</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="599"/>
        <source>Diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="951"/>
        <source>Row height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chart&apos;s caption</source>
        <translation type="vanished">Заголовок діаграми</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="619"/>
        <source>Show caption</source>
        <translation>Показувати заголовок</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="626"/>
        <source>Show grid</source>
        <translation>Показати сітку</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="633"/>
        <source>Show legend</source>
        <translation>Показувати легенду</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="640"/>
        <source>Set the params of the graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="663"/>
        <source>Real values</source>
        <translation>Реальні значення</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="673"/>
        <source>Percent values</source>
        <translation>Значення у відсотках</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="700"/>
        <source>Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="711"/>
        <source>Add row</source>
        <translation>Додати рядок</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="725"/>
        <source>Remove row</source>
        <translation>Видалити рядок</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="739"/>
        <source>Up</source>
        <translation>Вгору</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="753"/>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <source>Новая строка</source>
        <translation type="vanished">Новий рядок</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="807"/>
        <source>Caption</source>
        <translation>Заголовок</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="812"/>
        <source>Value</source>
        <translation>Значення</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="817"/>
        <source>Color</source>
        <translation>Колір</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="833"/>
        <source>Barcode type</source>
        <translation>Тип штрихового коду</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="857"/>
        <source>Frame type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="845"/>
        <source>Value:</source>
        <translation>Значення:</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="183"/>
        <source>Process as image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="190"/>
        <source>Image from database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="219"/>
        <source>Attention! You may enter just ONE variable and not any text.</source>
        <translation>Увага! Ви можете внести лише одну змінну і більше жодного тексту.</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="593"/>
        <source>Diagram property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="607"/>
        <source>Chart caption</source>
        <translation>Заголовок діаграми</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="647"/>
        <source>Show graph caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="657"/>
        <source>Graph caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="877"/>
        <source>Height</source>
        <translation>Висота</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="884"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="935"/>
        <source>Dimensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="941"/>
        <source>Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="964"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="970"/>
        <source>Show Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="977"/>
        <source>Show Total column, by row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="984"/>
        <source>Show Total row, by column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="991"/>
        <source>Show Sub Total row, by column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="998"/>
        <source>Background color of Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1029"/>
        <source>Background color of Totals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1095"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="1102"/>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="260"/>
        <location filename="../EditFldDlg.cpp" line="323"/>
        <source>Empty line</source>
        <translation>Порожній рядок</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="260"/>
        <location filename="../EditFldDlg.cpp" line="323"/>
        <source>The field contains empty line at the end.
Remove it?</source>
        <translation>Поле в кінці містить порожню рядок. Видалити її?</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="657"/>
        <source>Save Image As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="659"/>
        <source>Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorDelegate</name>
    <message>
        <location filename="../mainwindow.cpp" line="59"/>
        <source>Left</source>
        <translation>Вліво</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="60"/>
        <location filename="../mainwindow.cpp" line="70"/>
        <source>Center</source>
        <translation>По центру</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="61"/>
        <source>Right</source>
        <translation>Управо</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="62"/>
        <source>Justify</source>
        <translation>Вирівняти по ширині</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="69"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="71"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FldPropertyDlg</name>
    <message>
        <location filename="../FldPropertyDlg.ui" line="14"/>
        <source>Expression editor</source>
        <translation>Редактор виразів</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="66"/>
        <source>Data filed grouping</source>
        <translation>Поле угрупування даних</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="78"/>
        <source>Start line numeration for each group</source>
        <translation>Починати нову нумерция рядків для кожної групи</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="88"/>
        <source>Start new page for each group</source>
        <translation>Починати нову сторінку для кожної групи</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="114"/>
        <source>Category</source>
        <translation>Категорія</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="121"/>
        <source>Number</source>
        <translation>Число</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="132"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="146"/>
        <source>Other</source>
        <translation>Інше</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="167"/>
        <source>Precision</source>
        <translation>Точність</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="198"/>
        <source>Format string</source>
        <translation>Рядок формату</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="212"/>
        <source>Clear</source>
        <translation>Очистити</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="243"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="250"/>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="58"/>
        <location filename="../FldPropertyDlg.cpp" line="97"/>
        <source>Variables</source>
        <translation>Змінні</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="59"/>
        <source>System variables</source>
        <translation>Системні змінні</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="101"/>
        <location filename="../FldPropertyDlg.cpp" line="244"/>
        <source>Functions</source>
        <translation>Функції</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="104"/>
        <source>Aggregate functions</source>
        <translation>Агрегатні функції</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="139"/>
        <source>Text functions</source>
        <translation>Текстові функції</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="145"/>
        <source>To upper case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="152"/>
        <source>To lower case</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="159"/>
        <source>English</source>
        <translation>Англійська English</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="166"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="173"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="180"/>
        <source>Spanish</source>
        <translation>Іспанський Spanish</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="187"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="194"/>
        <source>French(BE)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="201"/>
        <source>French(CH)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="208"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="216"/>
        <source>Math functions</source>
        <translation>Математичні функції</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="250"/>
        <source>Data Group property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="258"/>
        <source>Formatting</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphicsBox</name>
    <message>
        <location filename="../Graphics/GraphicsBox.cpp" line="58"/>
        <source>New Label</source>
        <translation type="unfinished">Нова мітка</translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="obsolete">Разом</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsBox.cpp" line="861"/>
        <source>New image</source>
        <translation type="unfinished">Нова картинка</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsBox.cpp" line="867"/>
        <source>New diagram</source>
        <translation type="unfinished">Нова діаграма</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsBox.cpp" line="932"/>
        <source>Edit</source>
        <translation type="unfinished">Редагувати</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsBox.cpp" line="936"/>
        <source>Delete</source>
        <translation type="unfinished">Видалити</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsBox.cpp" line="942"/>
        <source>Move forward</source>
        <translation type="unfinished">Перемістити вперед</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsBox.cpp" line="948"/>
        <source>Move back</source>
        <translation type="unfinished">Перемістити назад</translation>
    </message>
</context>
<context>
    <name>GraphicsLine</name>
    <message>
        <location filename="../Graphics/GraphicsLine.cpp" line="434"/>
        <source>Delete</source>
        <translation type="unfinished">Видалити</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsLine.cpp" line="440"/>
        <source>Move forward</source>
        <translation type="unfinished">Перемістити вперед</translation>
    </message>
    <message>
        <location filename="../Graphics/GraphicsLine.cpp" line="446"/>
        <source>Move back</source>
        <translation type="unfinished">Перемістити назад</translation>
    </message>
</context>
<context>
    <name>ItemPropertyDlg</name>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="14"/>
        <source>Object property</source>
        <translation>Властивість об&apos;єкту</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="44"/>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="78"/>
        <source>Name</source>
        <translation>Ім&apos;я</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="105"/>
        <source>Relation property</source>
        <translation>Властивості зв&apos;язку</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="128"/>
        <source>Parent table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="145"/>
        <source>Columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="159"/>
        <source>reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="166"/>
        <source>Child table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="208"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="215"/>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>QtRPT Designer</source>
        <translation>QtRPT Designer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <location filename="../mainwindow.cpp" line="2043"/>
        <location filename="../mainwindow.cpp" line="2203"/>
        <source>Name</source>
        <translation>Ім&apos;я</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="157"/>
        <source>Value</source>
        <translation>Значення</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="195"/>
        <location filename="../mainwindow.cpp" line="324"/>
        <source>Report</source>
        <translation>Звіт</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Edit</source>
        <translation>Редагувати</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Help</source>
        <translation>Допомога</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="220"/>
        <source>Service</source>
        <translation>Сервіс</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="275"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="313"/>
        <source>toolBar_3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="335"/>
        <location filename="../mainwindow.ui" line="338"/>
        <source>Exit</source>
        <translation>Вихід</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="347"/>
        <source>Page settings</source>
        <translation>Налаштування сторінки</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="359"/>
        <location filename="../mainwindow.ui" line="362"/>
        <source>Select tool</source>
        <translation>Інструмент вибору</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="374"/>
        <location filename="../mainwindow.ui" line="377"/>
        <source>Align left</source>
        <translation>Вирівняти по лівому краю</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="389"/>
        <location filename="../mainwindow.ui" line="392"/>
        <source>Align center</source>
        <translation>Вирівняти по центру</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="404"/>
        <location filename="../mainwindow.ui" line="407"/>
        <source>Align right</source>
        <translation>Вирівняти по правому краю</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="419"/>
        <location filename="../mainwindow.ui" line="422"/>
        <location filename="../mainwindow.cpp" line="2068"/>
        <source>Justify</source>
        <translation>Вирівняти по ширині</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="434"/>
        <location filename="../mainwindow.ui" line="437"/>
        <location filename="../mainwindow.cpp" line="2224"/>
        <source>Bold</source>
        <translation>Жирний</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="449"/>
        <location filename="../mainwindow.ui" line="452"/>
        <location filename="../mainwindow.cpp" line="2234"/>
        <source>Italic</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="464"/>
        <location filename="../mainwindow.ui" line="467"/>
        <location filename="../mainwindow.cpp" line="2244"/>
        <source>Underline</source>
        <translation>Підкреслений</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="479"/>
        <location filename="../mainwindow.ui" line="482"/>
        <source>Top line</source>
        <translation>Верхня лінія</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="494"/>
        <location filename="../mainwindow.ui" line="497"/>
        <source>Bottom line</source>
        <translation>Нижня лінія</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="509"/>
        <location filename="../mainwindow.ui" line="512"/>
        <source>Left line</source>
        <translation>Ліва лінія</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="524"/>
        <location filename="../mainwindow.ui" line="527"/>
        <source>Right line</source>
        <translation>Права лінія</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="539"/>
        <location filename="../mainwindow.ui" line="542"/>
        <source>All frame line</source>
        <translation>Всі лінії обрамлення</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="554"/>
        <location filename="../mainwindow.ui" line="557"/>
        <source>No frame</source>
        <translation>Без обрамлення</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="569"/>
        <location filename="../mainwindow.ui" line="572"/>
        <source>Insert band</source>
        <translation>Вставити бенд</translation>
    </message>
    <message>
        <source>Add Filed</source>
        <translation type="vanished">Додати поле</translation>
    </message>
    <message>
        <source>Add filed</source>
        <translation type="vanished">Додати поле</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="587"/>
        <source>Add Fleld</source>
        <translation>Додати поле</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="590"/>
        <source>Add field</source>
        <translation>Додати поле</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="599"/>
        <location filename="../mainwindow.ui" line="602"/>
        <source>New report</source>
        <translation>Новий звіт</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="611"/>
        <location filename="../mainwindow.ui" line="614"/>
        <source>Open report</source>
        <translation>Відкрити звіт</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <source>Ctrl+O</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="629"/>
        <location filename="../mainwindow.ui" line="632"/>
        <source>Save report</source>
        <translation>Зберегти звіт</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="635"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="647"/>
        <location filename="../mainwindow.ui" line="650"/>
        <source>Align top</source>
        <translation>Вирівняти по верху</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="662"/>
        <location filename="../mainwindow.ui" line="665"/>
        <source>Align V center</source>
        <translation>Вирівняти вертикально по центру</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="677"/>
        <location filename="../mainwindow.ui" line="680"/>
        <source>Align bottom</source>
        <translation>Вирівняти по низу</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="689"/>
        <location filename="../mainwindow.ui" line="692"/>
        <source>Copy</source>
        <translation>Копіювати</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="695"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="704"/>
        <location filename="../mainwindow.ui" line="707"/>
        <source>Cut</source>
        <translation>Вирізувати</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="710"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="722"/>
        <location filename="../mainwindow.ui" line="725"/>
        <source>Paste</source>
        <translation>Вставити</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="728"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="737"/>
        <location filename="../mainwindow.ui" line="740"/>
        <source>Save as</source>
        <translation>Зберегти як</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="749"/>
        <location filename="../mainwindow.ui" line="752"/>
        <source>Font color</source>
        <translation>Колір шрифту</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="761"/>
        <location filename="../mainwindow.ui" line="764"/>
        <source>Background color</source>
        <translation>Колір фону</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="773"/>
        <location filename="../mainwindow.ui" line="776"/>
        <source>Border color</source>
        <translation>Колір рамки</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="785"/>
        <source>About QtRptDesigner</source>
        <translation>О QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="797"/>
        <source>Show Grid</source>
        <translation>Показати сітку</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="800"/>
        <source>Show/Hide grid</source>
        <translation>Показать/Спрятать сітку</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="815"/>
        <source>Add picture</source>
        <translation>Додати картинку</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="824"/>
        <location filename="../mainwindow.ui" line="827"/>
        <source>Frame style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="836"/>
        <location filename="../mainwindow.ui" line="839"/>
        <source>New Report Page</source>
        <translation>Нова сторінка звіту</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="848"/>
        <location filename="../mainwindow.ui" line="851"/>
        <source>Delete Report Page</source>
        <translation>Видалити сторінку звіту</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="860"/>
        <location filename="../mainwindow.ui" line="863"/>
        <source>Align Field Left</source>
        <translation>Вирівняти поле по лівому краю</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="872"/>
        <location filename="../mainwindow.ui" line="875"/>
        <source>Align Field Middle</source>
        <translation>Виравнять поле по середині</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="884"/>
        <location filename="../mainwindow.ui" line="887"/>
        <source>Align Field Right</source>
        <translation>Вирівняти поле по правому краю</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="896"/>
        <location filename="../mainwindow.ui" line="899"/>
        <source>Align Field Top</source>
        <translation>Вирівняти поле по верху</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="908"/>
        <location filename="../mainwindow.ui" line="911"/>
        <source>Align Field Center</source>
        <translation>Виравнять поле по центру</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="920"/>
        <location filename="../mainwindow.ui" line="923"/>
        <source>Align Field Bottom</source>
        <translation>Вирівняти поле по низу</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="932"/>
        <location filename="../mainwindow.ui" line="935"/>
        <source>Field Same Width</source>
        <translation>Поле такої ж ширини</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="944"/>
        <location filename="../mainwindow.ui" line="947"/>
        <source>Field Same Height</source>
        <translation>Поле такої ж висоти</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="956"/>
        <location filename="../mainwindow.ui" line="959"/>
        <source>Settings</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="971"/>
        <location filename="../mainwindow.ui" line="974"/>
        <source>Magnifying glass</source>
        <translation>Лупа</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="986"/>
        <location filename="../mainwindow.ui" line="989"/>
        <location filename="../mainwindow.cpp" line="2254"/>
        <source>Strikeout</source>
        <translation>Перекреслений</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="998"/>
        <location filename="../mainwindow.ui" line="1001"/>
        <source>Group property</source>
        <translation>Властивості групи</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1010"/>
        <location filename="../mainwindow.ui" line="1013"/>
        <source>Check updates</source>
        <translation>Перевірити оновлення</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1028"/>
        <location filename="../mainwindow.ui" line="1031"/>
        <source>Add Diagram</source>
        <translation>Додати діаграму</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1046"/>
        <location filename="../mainwindow.ui" line="1049"/>
        <source>Add Drawing</source>
        <translation>Додати малюнок</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1061"/>
        <location filename="../mainwindow.ui" line="1064"/>
        <source>Preview</source>
        <translation>Перегляд</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1076"/>
        <location filename="../mainwindow.ui" line="1079"/>
        <source>Data Source</source>
        <translation>Джерело даних</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1091"/>
        <location filename="../mainwindow.ui" line="1094"/>
        <source>Undo</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1097"/>
        <source>Ctrl+Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1109"/>
        <location filename="../mainwindow.ui" line="1112"/>
        <source>Redo</source>
        <translation>Повторити</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1115"/>
        <source>Ctrl+Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1130"/>
        <location filename="../mainwindow.ui" line="1133"/>
        <source>Add Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1142"/>
        <location filename="../mainwindow.ui" line="1145"/>
        <source>Readme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1160"/>
        <location filename="../mainwindow.ui" line="1163"/>
        <source>Add Rich Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1172"/>
        <location filename="../mainwindow.ui" line="1175"/>
        <source>To group</source>
        <translation>Згрупувати</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1184"/>
        <location filename="../mainwindow.ui" line="1187"/>
        <source>To ungroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1202"/>
        <location filename="../mainwindow.ui" line="1205"/>
        <source>Add CrossTab object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1220"/>
        <location filename="../mainwindow.ui" line="1223"/>
        <source>Add CrossTabBD object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="293"/>
        <source>Frame width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <source>Report Title</source>
        <translation>Заголовок звіту</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="438"/>
        <source>Report Summary</source>
        <translation>Підсумок звіту</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="444"/>
        <source>Page Header</source>
        <translation>Заголовок сторінки</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="450"/>
        <source>Page Footer</source>
        <translation>Підвал сторінки</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="456"/>
        <source>Master Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="482"/>
        <source>Master Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="476"/>
        <source>Master Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="251"/>
        <source>Font name</source>
        <translation>Ім&apos;я шрифту</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="254"/>
        <source>Font size</source>
        <translation>Розмір шрфіту</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="279"/>
        <source>Zoom</source>
        <translation>Масштабування</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="462"/>
        <source>Data Grouping Header</source>
        <translation>Заголовок групи даних</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="469"/>
        <source>Data Grouping Footer</source>
        <translation>Підвал групи даних</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>Line</source>
        <translation>Лінія</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Line with arrow at the end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="519"/>
        <source>Line with arrow at the start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="525"/>
        <source>Line with arrows at both side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="531"/>
        <source>Rectangle</source>
        <translation>Прямокутник</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="537"/>
        <source>Rounded rectangle</source>
        <translation>Прямокутник, що закругляється</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="543"/>
        <source>Ellipse</source>
        <translation>Еліпс</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="549"/>
        <source>Triangle</source>
        <translation>Трикутник</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="555"/>
        <source>Rhombus</source>
        <translation>Ромб</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="658"/>
        <source>&amp;%1 %2</source>
        <translation>&amp;%1 %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="824"/>
        <location filename="../mainwindow.cpp" line="1043"/>
        <source>Page %1</source>
        <translation>Сторінка %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="970"/>
        <location filename="../mainwindow.cpp" line="983"/>
        <location filename="../mainwindow.cpp" line="1741"/>
        <location filename="../mainwindow.cpp" line="2530"/>
        <source>Saving</source>
        <translation>Збереження</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="970"/>
        <location filename="../mainwindow.cpp" line="983"/>
        <location filename="../mainwindow.cpp" line="1741"/>
        <location filename="../mainwindow.cpp" line="2530"/>
        <source>The report was changed.
Save the report?</source>
        <translation>Звіт був змінений. Зберегти звіт?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="998"/>
        <source>Select File</source>
        <translation>Вибір файлу</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1229"/>
        <source>Going to make undo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1237"/>
        <source>Going to make redo: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1412"/>
        <source>Save File</source>
        <translation>Зберегти файл</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1412"/>
        <source>XML Files (*.xml)</source>
        <translation>XML Файли (*.xml)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1426"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1661"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1630"/>
        <location filename="../mainwindow.cpp" line="1669"/>
        <source>Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2049"/>
        <source>Aligment hor</source>
        <translation>Вирівнюванняпо  гір</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2053"/>
        <location filename="../mainwindow.cpp" line="2112"/>
        <location filename="../mainwindow.cpp" line="2139"/>
        <source>Left</source>
        <translation>Вліво</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2058"/>
        <location filename="../mainwindow.cpp" line="2086"/>
        <source>Center</source>
        <translation>По центру</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2063"/>
        <location filename="../mainwindow.cpp" line="2149"/>
        <source>Right</source>
        <translation>Управо</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2077"/>
        <source>Aligment ver</source>
        <translation>Вирівнювання по вір</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2081"/>
        <location filename="../mainwindow.cpp" line="2124"/>
        <location filename="../mainwindow.cpp" line="2159"/>
        <source>Top</source>
        <translation>Верх</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2091"/>
        <location filename="../mainwindow.cpp" line="2169"/>
        <source>Bottom</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2100"/>
        <source>Height</source>
        <translation>Висота</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2106"/>
        <source>Width</source>
        <translation>Ширіна</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2118"/>
        <source>Length</source>
        <translation>Довжина</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2193"/>
        <source>FrameWidth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2213"/>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2261"/>
        <source>Printing</source>
        <translation>Друк</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2267"/>
        <source>Start New Numeration</source>
        <translation>Починати нову нумерацію</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2273"/>
        <source>Show In Group</source>
        <translation>Показувати в групі</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2279"/>
        <source>Start New Page</source>
        <translation>Починати нову сторінку</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2285"/>
        <source>AutoHeight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2291"/>
        <source>IgnoreRatioAspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2297"/>
        <source>ArrowStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2303"/>
        <source>ArrowEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2309"/>
        <source>TextWrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2315"/>
        <source>BackgroundColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2321"/>
        <source>BorderColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2330"/>
        <source>FontColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2336"/>
        <source>BarcodeType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2342"/>
        <source>BarcodeFrameType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Report title</source>
        <translation type="vanished">Заголовок звіту</translation>
    </message>
    <message>
        <source>Report summary</source>
        <translation type="vanished">Підсумок звіту</translation>
    </message>
    <message>
        <source>Page header</source>
        <translation type="vanished">Заголовок сторінки</translation>
    </message>
    <message>
        <source>Page footer</source>
        <translation type="vanished">Підвал сторінки</translation>
    </message>
    <message>
        <source>Data Group Header</source>
        <translation type="vanished">Заголовок угрупування даних</translation>
    </message>
    <message>
        <source>Data Group Footer</source>
        <translation type="vanished">Підвал угрупування даних</translation>
    </message>
    <message>
        <source>This object %1 can&apos;t be a parent for %2</source>
        <translation type="vanished">Цей об&apos;єкт %1 не може бути батьком для %2</translation>
    </message>
</context>
<context>
    <name>PageSettingDlg</name>
    <message>
        <location filename="../PageSettingDlg.ui" line="32"/>
        <source>Page settings</source>
        <translation>Налаштування сторінки</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="42"/>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="51"/>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="56"/>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="61"/>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="66"/>
        <source>Letter</source>
        <translation>Letter</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="74"/>
        <source>Width</source>
        <translation>Ширіна</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="84"/>
        <location filename="../PageSettingDlg.ui" line="101"/>
        <location filename="../PageSettingDlg.ui" line="189"/>
        <location filename="../PageSettingDlg.ui" line="209"/>
        <location filename="../PageSettingDlg.ui" line="243"/>
        <location filename="../PageSettingDlg.ui" line="250"/>
        <source>cm</source>
        <translation>см</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="91"/>
        <source>Height</source>
        <translation>Висота</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="138"/>
        <source>Orientation</source>
        <translation>Орієнтація</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="146"/>
        <source>Portrait</source>
        <translation>Книжна</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="166"/>
        <source>Landscape</source>
        <translation>Альбомна</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="178"/>
        <source>Margins</source>
        <translation>Відступи</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="216"/>
        <source>Left</source>
        <translation>Вліво</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="223"/>
        <source>Right</source>
        <translation>Управо</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="257"/>
        <source>Top</source>
        <translation>Вгору</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="272"/>
        <source>Page border</source>
        <translation>Рамка сторінки</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="236"/>
        <source>Bottom</source>
        <translation>Низ</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="280"/>
        <source>Draw border</source>
        <translation>Малювати рамку</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="287"/>
        <source>Border color</source>
        <translation>Колір рамки</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="310"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="317"/>
        <source>Border width</source>
        <translation>Ширіна рамки</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="327"/>
        <source>Border style</source>
        <translation>Стиль рамки</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="364"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="371"/>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="61"/>
        <source>Cm</source>
        <translation>См</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="64"/>
        <source>Inch</source>
        <translation>Дюйм</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="29"/>
        <source>QtRptDesigner</source>
        <translation>QtRptDesigner</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../Graphics/UndoRedoCommands.cpp" line="30"/>
        <source>Moving box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Graphics/UndoRedoCommands.cpp" line="55"/>
        <source>Moving line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Graphics/UndoRedoCommands.cpp" line="99"/>
        <source>Delete</source>
        <translation type="unfinished">Видалити</translation>
    </message>
    <message>
        <location filename="../Graphics/UndoRedoCommands.cpp" line="142"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Graphics/UndoRedoCommands.cpp" line="179"/>
        <source>Changing Container&apos;s parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="obsolete">Разом</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="45"/>
        <source>Report title</source>
        <translation type="unfinished">Заголовок звіту</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="50"/>
        <source>Report summary</source>
        <translation type="unfinished">Підсумок звіту</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="55"/>
        <source>Page header</source>
        <translation type="unfinished">Заголовок сторінки</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="60"/>
        <source>Page footer</source>
        <translation type="unfinished">Підвал сторінки</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="65"/>
        <source>Master band</source>
        <translation type="unfinished">Основний бенд</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="70"/>
        <source>Master footer</source>
        <translation type="unfinished">Підвал даних</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="75"/>
        <source>Master header</source>
        <translation type="unfinished">Заголовок даних</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="80"/>
        <source>Data Group Header</source>
        <translation type="unfinished">Заголовок угрупування даних</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="85"/>
        <source>Data Group Footer</source>
        <translation type="unfinished">Підвал угрупування даних</translation>
    </message>
</context>
<context>
    <name>QTextEditEx</name>
    <message>
        <source>Cut</source>
        <translation type="vanished">Вирізувати</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="vanished">...</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="vanished">Копіювати</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="vanished">Вставити</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="vanished">Жирний</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="vanished">Курсив</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="vanished">Підкреслений</translation>
    </message>
    <message>
        <source>Align left</source>
        <translation type="vanished">Вирівняти по лівому краю</translation>
    </message>
    <message>
        <source>Align center</source>
        <translation type="vanished">Вирівняти по центру</translation>
    </message>
    <message>
        <source>Align right</source>
        <translation type="vanished">Вирівняти по правому краю</translation>
    </message>
    <message>
        <source>List</source>
        <translation type="vanished">Список</translation>
    </message>
    <message>
        <source>Font color</source>
        <translation type="vanished">Колір шрифту</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="vanished">Шрифт</translation>
    </message>
    <message>
        <source>Font size</source>
        <translation type="vanished">Розмір шрфту</translation>
    </message>
</context>
<context>
    <name>QtRPT</name>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1626"/>
        <source>Save as PDF</source>
        <translation>Зберегти як PDF</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1631"/>
        <source>Save as HTML</source>
        <translation>Зберегти як HTML</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1638"/>
        <source>Save as XLSX</source>
        <translation>Зберегти як XLSX</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1665"/>
        <location filename="../../QtRPT/qtrpt.cpp" line="1671"/>
        <location filename="../../QtRPT/qtrpt.cpp" line="1677"/>
        <source>Save File</source>
        <translation>Зберегти файл</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1665"/>
        <source>PDF Files (*.pdf)</source>
        <translation>PFD файли</translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1671"/>
        <source>HTML Files (*.html)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../QtRPT/qtrpt.cpp" line="1677"/>
        <source>XLSX Files (*.xlsx)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RepScrollArea</name>
    <message>
        <location filename="../RepScrollArea.cpp" line="144"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReportBand</name>
    <message>
        <source>Report title</source>
        <translation type="vanished">Заголовок звіту</translation>
    </message>
    <message>
        <source>Report summary</source>
        <translation type="vanished">Підсумок звіту</translation>
    </message>
    <message>
        <source>Page header</source>
        <translation type="vanished">Заголовок сторінки</translation>
    </message>
    <message>
        <source>Page footer</source>
        <translation type="vanished">Підвал сторінки</translation>
    </message>
    <message>
        <source>Master band</source>
        <translation type="vanished">Основний бенд</translation>
    </message>
    <message>
        <source>Master footer</source>
        <translation type="vanished">Підвал даних</translation>
    </message>
    <message>
        <source>Master header</source>
        <translation type="vanished">Заголовок даних</translation>
    </message>
    <message>
        <source>Data Group Header</source>
        <translation type="vanished">Заголовок угрупування даних</translation>
    </message>
    <message>
        <source>Data Group Footer</source>
        <translation type="vanished">Підвал угрупування даних</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="95"/>
        <source>Delete</source>
        <translation>Видалити</translation>
    </message>
</context>
<context>
    <name>SettingDlg</name>
    <message>
        <location filename="../SettingDlg.ui" line="14"/>
        <source>Settings</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="24"/>
        <source>Grid</source>
        <translation>Сітка</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="32"/>
        <source>Measurement&apos;s unit</source>
        <translation>Одиниця виміру</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="42"/>
        <source>Cm</source>
        <translation>См</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="55"/>
        <source>Inch</source>
        <translation>Дюйм</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="66"/>
        <source>Grid&apos;s step</source>
        <translation>Крок сітки</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="85"/>
        <source>Show grid</source>
        <translation>Показати сітку</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="95"/>
        <source>Internationalization</source>
        <translation>Інтернаціоналізація</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="103"/>
        <source>Language:</source>
        <translation>Мова:</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="111"/>
        <source>System Default</source>
        <translation>Системна мова</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="116"/>
        <source>Arabic عربي</source>
        <translation>Арабський عربي</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="121"/>
        <source>American English</source>
        <translation>Американський English</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="126"/>
        <source>Chinese</source>
        <translation>Китайська</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="131"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="136"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="141"/>
        <source>Georgian ქართული</source>
        <translation>Грузинський ქართული</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="146"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="151"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="156"/>
        <source>Portuguese</source>
        <translation>Португальський</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="161"/>
        <source>Russian Русский</source>
        <translation>Російський Русский</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="176"/>
        <source>Spanish</source>
        <translation>Іспанський Spanish</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="181"/>
        <source>Tamil தமிழ்</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="186"/>
        <source>Ukraine Український</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="166"/>
        <source>Serbian</source>
        <translation>Сербський</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="171"/>
        <source>Serbian Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="199"/>
        <source>Check updates during start application</source>
        <translation>Перевіряти оновлення під час старту програми</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="221"/>
        <source>Save</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="228"/>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="150"/>
        <source>Message QtRptDesigner</source>
        <translation>Повідомлення QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="151"/>
        <source>The language for this application has been changed.
The change will take effect the next time the application is started.
Restart application?</source>
        <translation>Мова для цього додатку була змінена.
Зміни почнуть діяти при наступному застосуванні додатку.
Перезапуск додатка?</translation>
    </message>
</context>
<context>
    <name>SqlDesigner</name>
    <message>
        <location filename="../SqlDesigner.ui" line="34"/>
        <source>Custom DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="44"/>
        <source>SQL DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="114"/>
        <source>Driver</source>
        <translation>Драйвер</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="105"/>
        <source>Connection&apos;s parameters</source>
        <translation>Параметри з&apos;єднання</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="51"/>
        <source>XML DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="203"/>
        <source>Connection name</source>
        <translation>Ім&apos;я з&apos;єднання</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="210"/>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="324"/>
        <source>Select XML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="388"/>
        <source>Field name</source>
        <translation>Ім&apos;я поля</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="393"/>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="404"/>
        <source>Preview data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="441"/>
        <location filename="../SqlDesigner.ui" line="444"/>
        <source>Clear diagram</source>
        <translation>Очистити діаграму</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="459"/>
        <location filename="../SqlDesigner.ui" line="462"/>
        <source>Select</source>
        <translation>Вибрати</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="471"/>
        <location filename="../SqlDesigner.ui" line="474"/>
        <source>Redo</source>
        <translation>Повторити</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="477"/>
        <source>Ctrl+Y</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="486"/>
        <location filename="../SqlDesigner.ui" line="489"/>
        <source>Undo</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="492"/>
        <source>Ctrl+Z</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="504"/>
        <location filename="../SqlDesigner.ui" line="507"/>
        <source>Add relationship</source>
        <translation>Додати зв&apos;язок</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="516"/>
        <location filename="../SqlDesigner.ui" line="519"/>
        <source>Delete</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="522"/>
        <source>Del</source>
        <translation>Видалити</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="161"/>
        <source>Connection</source>
        <translation>З&apos;єднання</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="154"/>
        <source>Check</source>
        <translation>Перевірити</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="196"/>
        <source>DB name</source>
        <translation>Ім&apos;я БД</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="168"/>
        <source>User name</source>
        <translation>Ім&apos;я користувача</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="182"/>
        <source>Host name</source>
        <translation>Ім&apos;я хоста</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="144"/>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="175"/>
        <source>Connection coding</source>
        <translation>Кодування з&apos;єднання</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="121"/>
        <location filename="../SqlDesigner.ui" line="189"/>
        <source>UTF8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="134"/>
        <source>Charset coding</source>
        <translation>Кодування шрифтів</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="288"/>
        <source>SQL query</source>
        <translation>SQL запит</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="88"/>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="88"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="91"/>
        <source>Info</source>
        <translation>Інфо</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="91"/>
        <source>Connected</source>
        <translation>Підключено</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="162"/>
        <source>Select File</source>
        <translation>Вибір файлу</translation>
    </message>
</context>
<context>
    <name>TContainerField</name>
    <message>
        <source>New Label</source>
        <translation type="vanished">Нова мітка</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="vanished">Редагувати</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Видалити</translation>
    </message>
    <message>
        <source>Move forward</source>
        <translation type="vanished">Перемістити вперед</translation>
    </message>
    <message>
        <source>Move back</source>
        <translation type="vanished">Перемістити назад</translation>
    </message>
    <message>
        <source>New image</source>
        <translation type="vanished">Нова картинка</translation>
    </message>
    <message>
        <source>New diagram</source>
        <translation type="vanished">Нова діаграма</translation>
    </message>
    <message>
        <source>Total</source>
        <translation type="vanished">Разом</translation>
    </message>
</context>
<context>
    <name>TContainerLine</name>
    <message>
        <source>Delete</source>
        <translation type="vanished">Видалити</translation>
    </message>
</context>
<context>
    <name>UpdateDlg</name>
    <message>
        <source>Updating</source>
        <translation type="vanished">Оновлення</translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="vanished">Виконання</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">Відновити</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">Відміна</translation>
    </message>
    <message>
        <source>Open Directory</source>
        <translation type="vanished">Відкрити каталог</translation>
    </message>
    <message>
        <source>Downloading %0. ..</source>
        <translation type="vanished">Завантажено %0. ..</translation>
    </message>
</context>
<context>
    <name>XYZTextEditor</name>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="43"/>
        <source>Cut</source>
        <translation>Вирізувати</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="46"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="63"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="80"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="113"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="133"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="153"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="189"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="209"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="229"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="249"/>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="308"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="60"/>
        <source>Copy</source>
        <translation>Копіювати</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="77"/>
        <source>Paste</source>
        <translation>Вставити</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="110"/>
        <source>Bold</source>
        <translation>Жирний</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="130"/>
        <source>Italic</source>
        <translation>Курсив</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="150"/>
        <source>Underline</source>
        <translation>Підкреслений</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="186"/>
        <source>Align left</source>
        <translation>Вирівняти по лівому краю</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="206"/>
        <source>Align center</source>
        <translation>Вирівняти по центру</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="226"/>
        <source>Align right</source>
        <translation>Вирівняти по правому краю</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="246"/>
        <source>Align jusify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="282"/>
        <source>List</source>
        <translation>Список</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="305"/>
        <source>Font color</source>
        <translation>Колір шрифту</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="322"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="332"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="438"/>
        <source>TextDirection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.ui" line="441"/>
        <source>&lt;-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="99"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="100"/>
        <source>Bullet List (Disc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="101"/>
        <source>Bullet List (Circle)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="102"/>
        <source>Bullet List (Square)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="103"/>
        <source>Ordered List (Decimal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="104"/>
        <source>Ordered List (Alpha lower)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_TextEditor.cpp" line="105"/>
        <source>Ordered List (Alpha upper)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XYZUpdateDlg</name>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="14"/>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="38"/>
        <source>Updating</source>
        <translation>Оновлення</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="33"/>
        <source>Progress</source>
        <translation>Виконання</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="82"/>
        <source>Update</source>
        <translation>Відновити</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.ui" line="89"/>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.cpp" line="55"/>
        <source>Open Directory</source>
        <translation>Відкрити каталог</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/XYZ_UpdateDlg.cpp" line="77"/>
        <source>Downloading %0. ..</source>
        <translation>Завантажено %0. ..</translation>
    </message>
</context>
</TS>
